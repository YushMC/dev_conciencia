import{r as e}from"./BMBH4PQv.js";const s=e(!1),n=()=>({isResponsiveMenu:s});export{n as u};
