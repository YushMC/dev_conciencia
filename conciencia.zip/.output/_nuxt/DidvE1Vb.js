import"./BMBH4PQv.js";const t=""+new URL("logo_without_bg.dVGxuL3I.png",import.meta.url).href;export{t as _};
