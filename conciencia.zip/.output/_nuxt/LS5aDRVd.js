import{_ as e}from"./DlAUqK2U.js";import{c,o}from"./BMBH4PQv.js";const r={};function t(n,s){return o(),c("div")}const f=e(r,[["render",t]]);export{f as default};
