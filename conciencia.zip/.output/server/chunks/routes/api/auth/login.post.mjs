import { c as defineEventHandler, r as readBody, e as setCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';
import 'node:path';

const login_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { token } = body;
  if (!token) {
    return { status: 401, message: "No autorizado" };
  }
  setCookie(event, "auth_token", token, {
    httpOnly: true,
    // secure: "production" === 'production',
    secure: true,
    sameSite: true,
    maxAge: 60 * 60 * 24 * 7,
    path: "/"
  });
  return { success: true };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
