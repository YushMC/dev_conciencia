import { c as defineEventHandler, g as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';
import 'node:path';

const user_get = defineEventHandler((event) => {
  const token = getCookie(event, "auth_token");
  if (!token) {
    return { authenticated: false };
  }
  return { authenticated: true, token };
});

export { user_get as default };
//# sourceMappingURL=user.get.mjs.map
