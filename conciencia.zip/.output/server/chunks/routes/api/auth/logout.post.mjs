import { c as defineEventHandler, e as setCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';
import 'node:path';

const logout_post = defineEventHandler((event) => {
  setCookie(event, "auth_token", "", {
    httpOnly: true,
    secure: true,
    sameSite: true,
    maxAge: -1,
    // 🔴 Esto elimina la cookie inmediatamente
    path: "/"
  });
  return { success: true };
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
